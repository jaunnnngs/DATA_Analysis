import torch
from torchvision import transforms
from torch.utils.data import DataLoader
import cv2
import os
import shutil

from cnn_model import ConvNet
from custom_dataset import CustomDataset
# from custom_dataset import CLASS_NAME


def main():
    pass

if __name__ == '__main__':
    main()