import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import transforms
from torch.utils.data import DataLoader
from tqdm import tqdm
import torchvision.models as models


from cnn_model import ConvNet
from custom_dataset import CustomDataset

def main():
    pass
    # model 지정하기

    # 모델 가져오기

    # loss function, optimizer(learning rate) 지정하기

    # batch size, epoch 지정

    # train용 dataset 불러오기

    # valid용 dataset 불러오기

    # 학습 및 validation


if __name__ == '__main__':
    main()